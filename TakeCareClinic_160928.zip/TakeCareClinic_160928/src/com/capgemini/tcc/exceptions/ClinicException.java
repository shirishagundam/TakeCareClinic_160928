package com.capgemini.tcc.exceptions;

public class ClinicException extends Exception {

	private String message;

	public ClinicException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
